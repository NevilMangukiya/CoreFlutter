import '../app_colors_page.dart';

class Global2 {
  static List<Contact> allcontacts = [];
}
