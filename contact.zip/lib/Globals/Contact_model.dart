import 'dart:io';

import '../app_colors_page.dart';

class Global {
  static File? image;
  static String? Firstname;
  static String? Lastname;
  static String? phone;
  static String? Email;

  // class Global2 {
  static List<Contact> allcontacts = [];
  // }

}
